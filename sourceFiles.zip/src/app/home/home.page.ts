import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  url = 'https://jsonplaceholder.typicode.com/posts'
  postArray : any
  searchText: string = ''
  constructor(private apiService : ApiService) {}

  ngOnInit(){
    console.log("home page-->")
    this.getData()
  }

  ionViewWillEnter(){
  }

  getData(){
    this.apiService.callGet(this.url).then((res : any) => {
      console.log(res)
      this.postArray = res
    },
    (err :any) =>{
      alert("Something went wrong!")
    })
  }
}
