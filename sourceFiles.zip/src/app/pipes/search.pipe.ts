import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchPipe'
})
export class SearchPipe implements PipeTransform {

  
  transform(value : any, filter : any) {
    console.log(value)
    console.log(filter)
    let resultArray :any = [];
    
    if(filter !=  null && filter != "" ){
      let resArr = []
      for (let item of value){
        if(item.title.toString().toLowerCase().indexOf(filter) !== -1){
          resArr.push(item)
        }
      }
      resultArray = resArr
      return resultArray;
    }
    
    return value;
  }

}
