import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(public http : HttpClient) { }

  callGet(url: any, reqObj? : any){
    return new Promise((resolve, reject) => {
      this.http.get<any>(url,{})
      .subscribe(
        async (response :any) => {
          resolve(response)
        },
        async (error : any) => {
          reject(error)
          alert("Something went wrong!");
        }
      )

    })
}
}
